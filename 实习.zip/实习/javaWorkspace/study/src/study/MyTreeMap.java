package study;

/*
 * HashMap���̲߳���ȫ��Ч�ʸߣ�����key����valueΪnull
 * Hashtable:�̲߳���ȫ��������key����valueΪnull
 */

import java.util.Map;
import java.util.TreeMap;

public class MyTreeMap {

	public static void main(String[] args) {
		Emp emp1 = new Emp(111, "wang", 2000.2);
		Emp emp2 = new Emp(113, "wang", 3000);
		Emp emp3 = new Emp(112, "wang", 2000.2);
		
		Map<Emp, String > treeMap = new TreeMap<>();
		treeMap.put(emp1, "lll");
		treeMap.put(emp2, "hhh");
		treeMap.put(emp3, "hhhhh");
		
		for(Emp key:treeMap.keySet()) {
			System.out.println(key);
		}

	}

}


class Emp implements Comparable<Emp>{
	int id;
	String name;
	double salary;
	public Emp(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	
	@Override
	public int compareTo(Emp o) {  //Returns a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than the specified object. 
		if (this.salary<o.salary) {
			return -1;
		}else if (this.salary>o.salary) {
			return 1;
		}else {
			if (this.id<o.id) {
				return -1;
			}else if (this.id>o.id) {
				return 1;
			}
		}
		return 0;
	}

	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", salary=" + salary;
	}
	
}
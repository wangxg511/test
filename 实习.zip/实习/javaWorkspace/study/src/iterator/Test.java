package iterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List list =new ArrayList();
		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		
		
		
		//ͨ������������list
		Iterator iter = list.iterator();
		while (iter.hasNext()) {
			String str = (String) iter.next();
			System.out.println(str);
	
		}
	}
}

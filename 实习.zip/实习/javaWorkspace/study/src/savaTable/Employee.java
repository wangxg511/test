package savaTable;


/*
 * һ�����󱣴�һ������
 * һ�����Ӧһ�ű�
 */
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.crypto.Data;

public class Employee {   //javabean  ʵ����
	private int id;
	private String name;
	private int salary;
	private String separtment;
	private Date jionData;
		
		
	public Employee(int id,String name,int salary,String separtment, String jionData) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.separtment = separtment;
		
		DateFormat format = new SimpleDateFormat("yyyy-MM");
		try {
			this.jionData = format.parse(jionData);
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	public String getSepartment() {
		return separtment;
	}


	public void setSepartment(String separtment) {
		this.separtment = separtment;
	}


	public Date getJionData() {
		return jionData;
	}


	public void setJionData(Date jionData) {
		this.jionData = jionData;
	}
	
	
		
}



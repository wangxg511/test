package savaTable;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes.Name;

public class Test1 {
	public static void main(String[] args) throws ParseException {
		Employee tom = new Employee(111,"tom",30000,"dev","2018-11");
		Employee join = new Employee(112,"join",30000,"dev","2018-11");
		Employee lll = new Employee(113,"lll",30000,"dev","2018-11");
		
		List<Employee> lst = new ArrayList<Employee>();
		lst.add(tom);
		lst.add(join);
		lst.add(lll);
		
		printEmployeename(lst);
		
	}
	public static void printEmployeename(List<Employee> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getName());
			
		}
	}
	
}

package savaTable;

/*
 * һ��list��Ӧһ������
 * һ��map��Ӧһ������
 */

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.crypto.Data;

public class Test2 {

	public static void main(String[] args) {
		Map map = new HashMap();
		map.put("id", 111);
		map.put("name", "tom");
		map.put("salary", 3000);
		map.put("deparment","dev");
		
		DateFormat format = new SimpleDateFormat("yyyy-MM");
		try {
			Date dt = format.parse("2018-10");
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		map.put("jionData", "2018-10");
		
		Map map2 = new HashMap();
		map2.put("id", 112);
		map2.put("name", "jion");
		map2.put("salary", 3000);
		map2.put("deparment","dev");
		try {
			Date dt =  format.parse("2018-10");
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		map2.put("jionData", "2018-10");
		
		
		List<Map> list =new ArrayList<Map>();
		
		list.add(map);
		list.add(map2);
		
		print(list);
		
	}
	
	public static void print(List<Map> list) {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).get("name"));
		}
	}

}










package set;

import java.util.HashMap;

public class MySet {
	  private HashMap map;
	  private static final Object PRESENT = new Object();
	  public MySet() {
		map = new HashMap();
	}
	  
	  public void add(Object obj) {
		  map.put(obj, PRESENT);
		
	}
	  public int size() {
		return map.size();
	}
	  public static void main(String[] args) {
		MySet mySet = new MySet();
		mySet.add("aaa");
		System.out.println(mySet.size());
	}

}

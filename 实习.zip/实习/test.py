from elasticsearch import Elasticsearch
# 默认host为localhost,port为9200.但也可以指定host与port
es = Elasticsearch("192.168.56.11:9200")

# 添加或更新数据,如果文档不存在，则会创建文档，如果文档存在，则会更新，版本号加1，index，doc_type名称可以自定义，id可以根据需求赋值,body为内容
es.index(index="my_index",doc_type="test_type",id=1,body={"name":"python","addr":"深圳"})

# 创建文档，如果文档存在会报异常，但是加上ignore=409，则会文档存在的时候忽略异常并且不会创建异常
es.create(index="my_index",doc_type="test_type",id=2,ignore=409,body={"name":"python","addr":"lll"})



# 获取索引为my_index,文档类型为test_type的所有数据,result为一个字典类型
result = es.search(index="my_index",doc_type="test_type",body={
    "query" : {
					"match" : {
						"addr" : "深圳"
					}
				}
})
print(result)
# 或者这样写:搜索id=1的文档
# result = es.get(index="my_index",doc_type="test_type",id=1)

# 打印所有数据
for item in result["hits"]["hits"]:
    print(item["_source"])

es.create
result = es.search(index="my_index",doc_type="test_type")
print(result)


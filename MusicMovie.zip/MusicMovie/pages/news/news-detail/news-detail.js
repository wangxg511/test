var newsData = require("../../data/news-data.js");
Page({
  data: {
    musicflag: false
  },
  onLoad: function (option) {
    var newsId = option.id;
    this.data.currentNewsId = newsId;
    var newsDataItem = newsData.newsData[newsId];
    this.setData(newsDataItem);
    // 缓存:在小程序中，如果用户不主动清除，则一直存在，缓存最大上限10M
    // 同步
    // wx.setStorageSync('key', "哈哈哈");
    // 修改缓存
    // wx.setStorageSync('key', {
    //   game:"穿越火线",
    //   dev:"timi"
    // })
    // //获取缓存
    // var myData = wx.getStorageSync("key");
    // console.log(myData);
    // 删除缓存
    // wx.removeStorageSync('key');
    // 清除所有缓存
    // wx.clearStorageSync();
    // 缓存存储数据值得格式
    // var newsCollected = {
    //   0:true,
    //   1:false
    // }
    // 收藏功能处理
    var newsCollected = wx.getStorageSync('news_Collected');
    if (newsCollected) {
      var collected = newsCollected[newsId];
      this.setData({
        collected: collected
      });
    } else {
      var newsCollected = {};
      newsCollected[newsId] = false;
      wx.setStorageSync('news_Collected', newsCollected);
    }
  },

  onCollected: function (event) {
    var newsCollected = wx.getStorageSync('news_Collected');
    var newCollected = newsCollected[this.data.currentNewsId];
    newCollected = !newCollected;
    newsCollected[this.data.currentNewsId] = newCollected;
    //最新的状态放入到缓存中
    wx.setStorageSync('news_Collected', newsCollected);
    //更新当前页面状态
    this.setData({
      collected: newCollected
    })
    wx.showToast({
      title: newCollected ? "收藏成功" : "取消成功",
      duration: 1000
    })
  },

  shareTap: function (event) {
    wx.showActionSheet({
      itemList: [
        "乐章",
        "听过",
        "乐趣",
        "聊聊"
      ],
      itemColor: "#c00",
      success: function (res) {
        wx.showToast({
          title: "暂时无法前往",
          duration: 1000
        })
      }
    })
  },
  onShareAppMessage: function () {
    // 用户点击右上角分享
    return {
      title: '蓝莓派', // 分享标题
      desc: '和音乐一起分享时光', // 分享描述
      path: 'http://www.iwen.wiki/blog' // 分享路径
    }
  },

  //播放音乐
  playermusic: function (event) {
    var currentNewsId = this.data.currentNewsId;
    var musicData = newsData.newsData[currentNewsId].music;
    var musicflag = this.data.musicflag;
    if (musicflag) {
      wx.pauseBackgroundAudio();
      this.setData({
        musicflag: false
      })
      
    } else {
      wx.playBackgroundAudio({
        dataUrl: musicData.url,
        title: musicData.title,
        coverImgUrl: musicData.coverImg,
      })
      this.setData({
        musicflag: true
      })
    }
  }
})
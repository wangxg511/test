var newsData = require("../data/news-data.js");
Page({
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    vertical: false
  },
  onLoad: function (options) {
    // 生命周期函数--监听页面加载
    //等同于加入到data中
    this.setData({
      newsData: newsData.newsData
    });
  },
  //跳转详情
  onnewsdetail: function (event) {
    var newsId = event.currentTarget.dataset.newsid;
    wx.navigateTo({
      url: 'news-detail/news-detail?id=' + newsId
    })
  },
  

  //轮播图跳转详情
  onSwiperItemTap:function(event){
    var newsId = event.currentTarget.dataset.newsid;
    wx.navigateTo({
      url: 'news-detail/news-detail?id=' + newsId
    })
  },
  // 冒泡事件
  onSwiperTap:function(event){
    var newsId = event.target.dataset.newsid;
    wx.navigateTo({
      url: 'news-detail/news-detail?id=' + newsId
    })
  },

  onReady: function () {
    // 生命周期函数--监听页面初次渲染完成
  },
  onShow: function () {
    // 生命周期函数--监听页面显示
  },
  onHide: function () {
    // 生命周期函数--监听页面隐藏
  },
  onUnload: function () {
    // 生命周期函数--监听页面卸载
  },
  onPullDownRefresh: function () {
    // 页面相关事件处理函数--监听用户下拉动作
  },
  onReachBottom: function () {
    // 页面上拉触底事件的处理函数
  },
  onShareAppMessage: function () {
    // 用户点击右上角分享
    return {
      title: '蓝莓派', // 分享标题
      desc: '和音乐一起分享时光', // 分享描述
      path: 'http://www.iwen.wiki/blog' // 分享路径
    }
  }
})
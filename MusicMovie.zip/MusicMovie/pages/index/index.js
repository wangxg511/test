Page({
    data: {

    },
    goNews: function () {
        wx.switchTab({
            url: '../news/news',
            success: function () {
                console.log("success");
            },
            fail: function () {
                console.log("fail");
            },
            complete: function () {
                console.log("complete");
            }
        })
    },
    onLoad: function () {
    },

    lookLocation: function () {
        wx.getLocation({
            type: 'gcj02', //返回可以用于wx.openLocation的经纬度
            success: function (res) {
                var latitude = res.latitude
                var longitude = res.longitude
                wx.openLocation({
                    latitude: latitude,
                    longitude: longitude,
                    scale: 15,
                    name: "尚学堂",
                    address: "西三旗桥东，建材城西路"
                })
            }
        })
    },

    callMeTap: function () {
        wx.makePhoneCall({
            phoneNumber: '17600220403' 
        })
    }
})
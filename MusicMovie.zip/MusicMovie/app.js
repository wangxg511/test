App({
    globalData:{
        doubanBase:"https://api.douban.com"
    }
})
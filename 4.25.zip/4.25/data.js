let supportResult = await wepy.checkIsSupportSoterAuthentication().then(res => {
    var isSupportFinger = false;
    res.supportMode.forEach((item, index) => {
        if (item === 'fingerPrint') {
            isSupportFinger = true;
            return false;
        }
    });
 
    return isSupportFinger;
}).catch(() => {
    // 开发者工具不支持
    return false;
});
 
if (supportResult) {
    let enrolledResult = await wepy.checkIsSoterEnrolledInDevice({
        checkAuthMode: 'fingerPrint' //认证方式
    }).then(settingResult => {
        if (!settingResult.isEnrolled === false) {
            return { success: true, errMsg: '' }
        } else {
            return { success: false, errMsg: settingResult.errMsg }
        }
    });
 
    if (!enrolledResult.success === false) {
        // 本机已录入指纹信息
        let authResult = await wepy.startSoterAuthentication({
            requestAuthModes: ['fingerPrint'],
            challenge: 'fingerPrintSetting',
            authContent: '验证指纹提示语'
        }).then(enableResult => {
            return enableResult;
        }).catch(enableErrResult => {
            if (enableErrResult.errCode === 90008) {
                wepy.showToast({
                    title: '用户已取消', //提示的内容,
                    icon: 'none', //图标,
                    duration: 1000, //延迟时间,
                    mask: true //显示透明蒙层，防止触摸穿透
                });
            } else if (enableErrResult.errCode === 90009) {
                wepy.showToast({
                    title: '指纹验证失败', //提示的内容,
                    icon: 'none', //图标,
                    duration: 1000, //延迟时间,
                    mask: true //显示透明蒙层，防止触摸穿透
                });
            } else {
                wepy.showToast({
                    title: enableResult.errMsg, //提示的内容,
                    icon: 'none', //图标,
                    duration: 1000, //延迟时间,
                    mask: true //显示透明蒙层，防止触摸穿透
                });
            }
            return false;
        });
 
        if (!authResult === false) {
            // 将结果上传服务器传输给微信认证结果, TODO：目前服务端报 48001 错误，询问官方中
            wepy.showToast({
              title: '验证成功', // 提示的内容,
              icon: 'none', // 图标,
              duration: 1500, // 延迟时间,
              mask: true, // 显示透明蒙层，防止触摸穿透
            });
        }
    } else {
        wepy.showToast({
            title: settingResult.errMsg, // 提示的内容,
            icon: 'none', // 图标,
            duration: 1000, // 延迟时间,
            mask: true // 显示透明蒙层，防止触摸穿透
        });
    }
} else {
    wepy.showToast({
        title: '本机无法支持指纹识别', // 提示的内容,
        icon: 'none', // 图标,
        duration: 1000, // 延迟时间,
        mask: true // 显示透明蒙层，防止触摸穿透
    });
}



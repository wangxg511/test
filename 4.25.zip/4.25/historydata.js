var historyData=[
	{
		'openid':0,
		'studentIcon':'../images/shak.png',
		'studentName':'张三',
		'signDate':2017/2/2,
		'signLocation':'6203',
		'signCourse':'计算机网络'
		
	},
	{
		'openid':2,
		'studentIcon':'../images/shak.png',
		'studentName':'李思尔',
		'signDate':2017/2/2,
		'signLocation':'6203',
		'signCourse':'计算机网络'
		
	},
	{
		'openid':3,
		'studentIcon':'../images/shak.png',
		'studentName':'王五王五',
		'signDate':2017/2/2,
		'signLocation':'6203',
		'signCourse':'计算机网络'
		
	}

]

//导出数据，使其可以被外部访问
module.exports = {
	initData:initData
}




var historyData = require("../data/historyData.js");

pages({
	data:{
		useData:''
	}
	
	https:function(){
		//this.setDate可以view重绘
		//在数据绑定的时候只有text不需要加双引号
		this.setDate({
			//useData是pages中的变量，historyData是此文件第一行声明的变量，init是historydata.js中导出数据时定义的变量。
			useData:historData.initData
	})
		
	}
	
})
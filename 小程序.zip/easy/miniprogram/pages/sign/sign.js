
// pages/sign/sign.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      { name: 'jw', value: '计算机网络' },
      { name: 'jz', value: '计算机组成原理', checked: 'true' },
      { name: 'python', value: 'python程序设计' },
      
    ]},
  


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    wx.updateShareMenu({
      withShareTicket: true,
      success() { }
    })

  },
  radioChange(e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
  },
  signin:function(event){
    wx.checkIsSupportSoterAuthentication({
      success(res) {
        console.log(res)
        wx.checkIsSoterEnrolledInDevice({
          checkAuthMode: 'fingerPrint',
          success(res) {
            if (res.isEnrolled == 1) {
              // show("提示", "有指纹", false);
              wx.startSoterAuthentication({
                requestAuthModes: ['fingerPrint'],
                challenge: '123456',
                authContent: '请用指纹',
                success(res) {
                  console.log("识别成功", res)
                  // show("提示", "识别成功", false);
                },
                fail(res) {
                  console.log("识别失败", res)
                  // show("提示", "识别失败", false);
                }
              })
            } else if (res.isEnrolled == 0) {
              // show("提示", "无指纹", false);
              console.log("没有指纹")
            }
          },
          fail(res) {
            // show("提示", "异常", fail);
            console.log("meiyouzhiwen")
          }
        })
        // res.supportMode = [] 不具备任何被SOTER支持的生物识别方式
        // res.supportMode = ['fingerPrint'] 只支持指纹识别
        // res.supportMode = ['fingerPrint', 'facial'] 支持指纹识别和人脸识别




      }
    })
  },

  serversignin: function () {
    wx.checkIsSupportSoterAuthentication({
      success(res) {
        console.log(res)
        // wx.request({
        //   url: 'test.php', // 仅为示例，并非真实的接口地址
        //   data: {
        //     x: '',
        //     y: ''
        //   },
        //   method:'POST',
        //   success(res) {
        //     console.log(res.data)
        //   }
        // })
        // res.supportMode = [] 不具备任何被SOTER支持的生物识别方式
        // res.supportMode = ['fingerPrint'] 只支持指纹识别
        // res.supportMode = ['fingerPrint', 'facial'] 支持指纹识别和人脸识别




      }
    })


  }
})


